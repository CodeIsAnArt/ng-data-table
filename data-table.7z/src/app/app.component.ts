import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  // TBB Variable
  public tableHeadersList: String[] = ['a', 'b', 'c', 'd', 'e', 'f'];
  public tableData: any;
  public pageSize: number;
  public numberOfPages: number;
  public tableDataDetails = [{
    'name': 'qdwdqwd',
    'type': 'input',
    'subType': 'radio',
    'root': ''
  }, {
    'name': 'gergerge',
    'type': '',
    'root': ''
  }, {
    'name': '_id',
    'type': '',
    'root': ''
  }, {
    'name': 'blah',
    'type': '',
    'subType': 'checkbox',
    'root': 'test2'
  }, {
    'name': 'index',
    'type': '',
    'subType': 'button',
    'root': 'test2.test3.test4',
    'elementDesc': 'hello button'
  }, {
    'name': 'guid',
    'type': '',
    'root': 'test2.test3.test4'
  }];

  // Required Variables

  public currentPage;
  public scrollTracker;
  public counter1 = [1, 1, 1, 1, 1];
  // Temp Variable
  public url = 'http://www.json-generator.com/api/json/get/cfuneGYlAi?indent=2';
  public obs = this.http.get('http://www.json-generator.com/api/json/get/cpiScJKFcO?indent=2');

  constructor(private http: HttpClient) {
  }

  ngOnInit(): void {
    this.currentPage = 0;
    this.scrollTracker = 5;
    this.pageSize = 10;
    this.obs.subscribe(data => {
      this.tableData = data;
      this.numberOfPages = Math.ceil((this.tableData.length) / this.pageSize);
    });
    // this.numberOfPages = (this.tableData.length) / this.pageSize;
  }

  concatenatedName(item, detailsOfProperties) {
    const valueProperty = detailsOfProperties.name;
    if (detailsOfProperties.root) {
      const rootArray = detailsOfProperties.root.split('.');
      let innerObject = item;
      for (let i = 0; i < rootArray.length; i++) {
        innerObject = innerObject[rootArray[i]];
      }
      return innerObject[valueProperty];
    }
    return item[valueProperty];
  }

  counter() {
    return new Array(5);
  }

  paginatedtableData() {
    const startPoint = this.currentPage * this.pageSize;
    const endPoint = startPoint + this.pageSize;
    if (this.tableData) {
      return this.tableData.slice(startPoint, endPoint);
    }

  }

  navigateUsingPreviousOrNext(navigationDirection: String) {
    if (navigationDirection === 'previous' && this.currentPage > 0) {
      --this.currentPage;
      if (this.currentPage > 5 && this.currentPage < (this.numberOfPages - 2)) {
        --this.scrollTracker;
      }
    } else if (navigationDirection === 'next' && this.currentPage < (this.numberOfPages - 1)) {
      ++this.currentPage;
      if (this.currentPage > 5 && this.currentPage < (this.numberOfPages - 2)) {
        ++this.scrollTracker;
      }
    }
    console.log('scroll : ' + this.scrollTracker  + '  current : ' + this.currentPage);
  }

  jumpToAPage(newPage: String) {
    this.currentPage = newPage;
    if (this.scrollTracker > 5 && this.scrollTracker < (this.numberOfPages - 2)) {
      this.scrollTracker = newPage;
    } else {
      this.scrollTracker = 5;
    }
    console.log('scroll : ' + this.scrollTracker  + '  current : ' + this.currentPage);
  }
}
